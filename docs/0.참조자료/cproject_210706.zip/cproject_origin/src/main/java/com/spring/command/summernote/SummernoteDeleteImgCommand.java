package com.spring.command.summernote;

public class SummernoteDeleteImgCommand {
	
	private String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
}
